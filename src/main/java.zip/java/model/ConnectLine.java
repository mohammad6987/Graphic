package model;

import javafx.scene.shape.Line;

public class ConnectLine extends Line {
    public ConnectLine(double v, double v1, double v2, double v3) {
        super(v, v1, v2, v3);//x1 & y1 & x2 & y2
    }
}
