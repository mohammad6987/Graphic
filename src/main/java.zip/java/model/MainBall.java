package model;

import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;

public class MainBall extends Circle {
    public MainBall(double v, double v1, double v2, Paint paint) {
        super(v, v1, v2, paint);
    }
}
